<div class="pull-right hidden-xs">
    <b>Version</b> 2.4.18
</div>
<strong>Copyright &copy; <script>document.write(new Date().getFullYear())</script> <a href="https://adminlte.io">Vikar Maulana Arrisyad</a>.</strong> All rights
reserved.
